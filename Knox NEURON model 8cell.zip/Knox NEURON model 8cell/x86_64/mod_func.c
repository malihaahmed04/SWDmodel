#include <stdio.h>
#include "hocdec.h"
extern int nrnmpi_myid;
extern int nrn_nobanner_;

extern void _Exp2Syn_AMPA_reg(void);
extern void _Exp2Syn_GABAa_reg(void);
extern void _HH2_reg(void);
extern void _IM_reg(void);
extern void _IT_reg(void);
extern void _IT2_reg(void);
extern void _ITREcustom_reg(void);
extern void _Ih_reg(void);
extern void _ampa_reg(void);
extern void _cadecay_reg(void);
extern void _gabaa_reg(void);
extern void _gabab_reg(void);
extern void _kleak_reg(void);
extern void _vecevent_reg(void);

void modl_reg(){
  if (!nrn_nobanner_) if (nrnmpi_myid < 1) {
    fprintf(stderr, "Additional mechanisms from files\n");

    fprintf(stderr," \"Exp2Syn_AMPA.mod\"");
    fprintf(stderr," \"Exp2Syn_GABAa.mod\"");
    fprintf(stderr," \"HH2.mod\"");
    fprintf(stderr," \"IM.mod\"");
    fprintf(stderr," \"IT.mod\"");
    fprintf(stderr," \"IT2.mod\"");
    fprintf(stderr," \"ITREcustom.mod\"");
    fprintf(stderr," \"Ih.mod\"");
    fprintf(stderr," \"ampa.mod\"");
    fprintf(stderr," \"cadecay.mod\"");
    fprintf(stderr," \"gabaa.mod\"");
    fprintf(stderr," \"gabab.mod\"");
    fprintf(stderr," \"kleak.mod\"");
    fprintf(stderr," \"vecevent.mod\"");
    fprintf(stderr, "\n");
  }
  _Exp2Syn_AMPA_reg();
  _Exp2Syn_GABAa_reg();
  _HH2_reg();
  _IM_reg();
  _IT_reg();
  _IT2_reg();
  _ITREcustom_reg();
  _Ih_reg();
  _ampa_reg();
  _cadecay_reg();
  _gabaa_reg();
  _gabab_reg();
  _kleak_reg();
  _vecevent_reg();
}
