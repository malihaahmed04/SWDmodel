To run Knox 8-cell model:
- nrngui rundemo.hoc
- Select 3Hz Spike and wave
- Run with gabaapercent = 100
- Run with gabaapercent = 0

Any changes need to be made to the Fspikewave.oc file 
 