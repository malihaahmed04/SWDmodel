#include <stdio.h>
#include "hocdec.h"
extern int nrnmpi_myid;
extern int nrn_nobanner_;

extern void _AMPA_S_reg(void);
extern void _GABAa_S_reg(void);
extern void _cadx_reg(void);
extern void _hhx2_reg(void);
extern void _iarx_reg(void);
extern void _imx_reg(void);
extern void _it2x_reg(void);
extern void _itx_reg(void);
extern void _kleakx_reg(void);
extern void _vecevent_reg(void);

void modl_reg(){
  if (!nrn_nobanner_) if (nrnmpi_myid < 1) {
    fprintf(stderr, "Additional mechanisms from files\n");

    fprintf(stderr," \"AMPA_S.mod\"");
    fprintf(stderr," \"GABAa_S.mod\"");
    fprintf(stderr," \"cadx.mod\"");
    fprintf(stderr," \"hhx2.mod\"");
    fprintf(stderr," \"iarx.mod\"");
    fprintf(stderr," \"imx.mod\"");
    fprintf(stderr," \"it2x.mod\"");
    fprintf(stderr," \"itx.mod\"");
    fprintf(stderr," \"kleakx.mod\"");
    fprintf(stderr," \"vecevent.mod\"");
    fprintf(stderr, "\n");
  }
  _AMPA_S_reg();
  _GABAa_S_reg();
  _cadx_reg();
  _hhx2_reg();
  _iarx_reg();
  _imx_reg();
  _it2x_reg();
  _itx_reg();
  _kleakx_reg();
  _vecevent_reg();
}
